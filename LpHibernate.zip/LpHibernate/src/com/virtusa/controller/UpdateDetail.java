package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.util.HibernateUtil;
//@WebServlet(urlPatterns="/update")
public class UpdateDetail extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("nm");
		String newEmail=req.getParameter("em1");
		String oldEmail=req.getParameter("em2");
		String password=req.getParameter("pass");
		long mobile=Long.parseLong(req.getParameter("mob"));
		String profession=req.getParameter("prof");
		String address=req.getParameter("add");
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
		Session session=null;
		String query1="update Lp "
				+ "set name=?,email=?,password=?,mobile=?,profession=?,address=?"
				+ "where email=?";
		try {
			SessionFactory factory=HibernateUtil.getFactory();
			  session=factory.openSession();
			 Transaction transaction=session.beginTransaction();
			 
	Query query=session.createQuery(query1);
			query.setString(0,name);
			query.setString(1,newEmail);
			query.setString(2,password);
			query.setLong(3,mobile);
			query.setString(4, profession);
			query.setString(5, address);
			query.setString(6, oldEmail);
			System.out.println("oldmail "+oldEmail);
		int value=query.executeUpdate();
		System.out.println(" row updated "+value);
		if(value>0)
		{
		out.print("Details updated successfully");
		req.getRequestDispatcher("/LpService.jsp").include(req, resp);
		}
		else
		{out.print(" Can not update detail please enter right  old Email Id");
		req.getRequestDispatcher("/update.jsp").include(req, resp);
		}
		
		} catch (Exception e) {
			
			out.print(" This new Email id already exist please try again with other email !");
			req.getRequestDispatcher("/update.jsp").include(req, resp);
			
		}
		finally
		{
			session.close();
		}
		System.out.println("everything is working fine");
		

	}
}
