package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.entity.Lp;
import com.virtusa.util.HibernateUtil;
/*@WebServlet(
urlPatterns="/enroll",
loadOnStartup=1,
asyncSupported=true)*/
public class LpEnrollmentServlet extends HttpServlet {
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String name=req.getParameter("nm");
	String email=req.getParameter("em");
	String password=req.getParameter("pass");
	long mobile=Long.parseLong(req.getParameter("mob"));
	String profession=req.getParameter("prof");
	String address=req.getParameter("add");
	String gender=req.getParameter("gender");
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();  
    Session session=null;
    try {
	 SessionFactory factory=HibernateUtil.getFactory();
	  session=factory.openSession();
	 Transaction transaction=session.beginTransaction();
	 Lp lp=new Lp(name, email, password, mobile, profession, address, gender);
	 session.persist(lp);
	 transaction.commit();
	
	
		out.print("Successfully you have Enrolled");
		req.getRequestDispatcher("/home.jsp").include(req, resp);
	
	
	} catch (Exception e) {
		e.printStackTrace();
		out.print("Enrollment Failed - This email Id already exists please try with other email id");
		req.getRequestDispatcher("/home.jsp").include(req, resp);
	}
	finally
	{
		session.close();
	}
	System.out.println("everything is working fine");
	

}
}
