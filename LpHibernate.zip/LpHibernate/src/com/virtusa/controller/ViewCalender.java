package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;


import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.entity.Calender;
import com.virtusa.util.HibernateUtil;
//@WebServlet(urlPatterns="/viewCalender")
public class ViewCalender extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
		Session session=null;
		String query="from Calender";
		try {
			SessionFactory factory=HibernateUtil.getFactory();
			  session=factory.openSession();
			 Transaction transaction=session.beginTransaction();
			 Query query1=session.createQuery(query);
	List<Calender> list=query1.list();
	
	
	if(list.size()>0)
	{
		req.setAttribute("data", list); 
		req.getRequestDispatcher("/viewCalender.jsp").forward(req, resp); 
	}
	else  {
	out.print("No calender Details Found Please try again later !");
		req.getRequestDispatcher("/LpService.jsp").include(req, resp); 
	}
		
		} 
	catch (Exception e) {
			
			e.printStackTrace();
		}
		finally
		{
			session.close();
		}
		System.out.println("everything is working view");
	}

}
