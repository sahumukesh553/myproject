package com.virtusa.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Trainee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int traineeId;
	private	String name;
	private	String email;
	
	private	long mobile;
	private	String profession;
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	private	String address;
	private	String gender;
	
	
	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Trainee(String name, String email, long mobile, String profession, String address, String gender) {
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.profession = profession;
		this.address = address;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId +" name=" + name + ", email=" + email + ", mobile=" + mobile + ", profession="
				+ profession + ", address=" + address + ", gender=" + gender + "]";
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	
	public long getMobile() {
		return mobile;
	}
	public String getProfession() {
		return profession;
	}
	public String getAddress() {
		return address;
	}
	public String getGender() {
		return gender;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
}
