package com.virtusa.entity;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
private String state;
private long pincode;
private String city;
private String street;
private String landmark;
public Address() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Address [state=" + state + ", pincode=" + pincode + ", city=" + city + ", street=" + street + ", landmark="
			+ landmark + "]";
}
public Address(String state, long pincode, String city, String street, String landmark) {
	this.state = state;
	this.pincode = pincode;
	this.city = city;
	this.street = street;
	this.landmark = landmark;
}
public String getState() {
	return state;
}
public long getPincode() {
	return pincode;
}
public String getCity() {
	return city;
}
public String getStreet() {
	return street;
}
public String getLandmark() {
	return landmark;
}
public void setState(String state) {
	this.state = state;
}
public void setPincode(long pincode) {
	this.pincode = pincode;
}
public void setCity(String city) {
	this.city = city;
}
public void setStreet(String street) {
	this.street = street;
}
public void setLandmark(String landmark) {
	this.landmark = landmark;
}




}
