package com.virtusa.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class BatchDetail {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int batchId;
private String batchName;
@OneToMany(cascade=CascadeType.ALL)
private List<Trainee> trainee;
public BatchDetail() {
	super();
	// TODO Auto-generated constructor stub
}
public BatchDetail( String batchName) {
	//this.batchId = batchId;
	this.batchName = batchName;
}
public int getBatchId() {
	return batchId;
}
public String getBatchName() {
	return batchName;
}
public List<Trainee> getTrainee() {
	return trainee;
}
public void setBatchId(int batchId) {
	this.batchId = batchId;
}
public void setBatchName(String batchName) {
	this.batchName = batchName;
}
public void setTrainee(List<Trainee> trainee) {
	this.trainee = trainee;
}


}
