package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.connection.DataBaseUtil;
import com.virtusa.model.*;

public class MentorDaoImpl implements MentorDao {

	static Logger logger=Logger.getLogger(MentorDaoImpl.class);

	@Override
	public boolean verifyLogin(Mentor mentor) {
		boolean result=false;
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultset=null;
		String query="select * from lpmanagement_system.mentor where email=? and password=?";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
			
			preparedStatement.setString(1,mentor.getEmail());
			preparedStatement.setString(2,mentor.getPassword());
	resultset	=preparedStatement.executeQuery();
	result=resultset.next();
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
			logger.error("Exception while verifying mentor login");
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	return result;
	}

	@Override
	public int createBatch(BatchDetail batch) {
		boolean result=false;
		List<Trainee> list=new ArrayList();
		Connection connection=null;
		PreparedStatement preparedStatement1=null;
		PreparedStatement preparedStatement2=null;
		PreparedStatement preparedStatement3=null;
		PreparedStatement preparedStatement4=null;
		PreparedStatement preparedStatement5=null;
		ResultSet resultset1=null;
		ResultSet resultset2=null;
		ResultSet resultset3=null;
		String query1="select * from lpmanagement_system.lp";
		String query2="insert into lpmanagement_system.batch_detail values(?,?,?,?,?,?,?,?)";
		String query3="insert into lpmanagement_system.batch values(?,?) ";
		String query4="select email from lpmanagement_system.batch_detail";
	String query5="select batch_name from lpmanagement_system.batch";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement1=connection.prepareStatement(query1);
			preparedStatement2=connection.prepareStatement(query2);
			preparedStatement3=connection.prepareStatement(query3);
			preparedStatement4=connection.prepareStatement(query4);
			preparedStatement5=connection.prepareStatement(query5);
			connection.setAutoCommit(false);
			System.out.println("prepare");
			resultset3=preparedStatement5.executeQuery();
			System.out.println("execute"+resultset3);
			List<String> batchNames=new ArrayList<String>();
			while(resultset3.next())
			{
				batchNames.add(resultset3.getString("batch_name"));
				System.out.println(resultset3.getString("batch_name"));
			}
			if(batchNames.contains(batch.getBatchName()))
			{System.out.println("duplicate name");
				return 0;
			}
			resultset2=preparedStatement4.executeQuery();
			List<String> existing=new ArrayList<String>();
			

			while(resultset2.next())
			{
				existing.add(resultset2.getString("email"));
			}
	resultset1	=preparedStatement1.executeQuery();
	System.out.println(" select qury"+resultset1);
	int count=0;
	while(resultset1.next())
	{

String name=resultset1.getString("name");
String email=resultset1.getString("email");
if(existing.contains(email))
	continue;
long mobile=resultset1.getLong("mobile");
String profession=resultset1.getString("profession");
String address=resultset1.getString("address");
String gender=resultset1.getString("gender");
String course=resultset1.getString("course");
list.add(new Trainee(name, email,course, mobile, profession, address, gender,batch.getBatchId()));

	}
	if(list.isEmpty())
	{System.out.println("trainee is empty");
		return 1;
	}
	preparedStatement3.setInt(1, batch.getBatchId());
	preparedStatement3.setString(2, batch.getBatchName());
	preparedStatement3.executeUpdate();
	for (Trainee trainee : list) {
		preparedStatement2.setString(1,trainee.getName());
		preparedStatement2.setString(2,trainee.getEmail());
		preparedStatement2.setLong(3,trainee.getMobile());
		preparedStatement2.setString(4,trainee.getProfession());
		preparedStatement2.setString(5,trainee.getCourse());
		preparedStatement2.setString(6,trainee.getAddress());
		preparedStatement2.setString(7,trainee.getGender());
		preparedStatement2.setInt(8,trainee.getBatchId());
		preparedStatement2.executeUpdate();
		count++;
		
		
	}
	
	if(count>0)
	{connection.commit();
	
	}
	else  {
		connection.rollback();

	}
		
		} 
	catch (ClassNotFoundException | SQLException e) {
		logger.error("Exception while creating Batch");
		
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return 2;
			
		}
		finally
		{
			try {
			preparedStatement1.close();
			preparedStatement2.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return 3;
	}

	@Override
	public boolean publishCalender(String[] dates,String []topics) {
		boolean result=false;
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String query="insert into lpmanagement_system.calender values(?,?)";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
			connection.setAutoCommit(false);
			int value=0;
			for(int i=0;i<dates.length;i++)
			{
			preparedStatement.setString(1,dates[i]);
			preparedStatement.setString(2,topics[i]);
			preparedStatement.executeUpdate();
			value++;
			}
		
		if(value==dates.length) 
		{connection.commit();
			result=true;
		} 
		else
		{connection.rollback();
		
			
		}
		
		} catch (ClassNotFoundException | SQLException e) {
			logger.error("Exception while publishing calender");
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return result;
	}
	

}
