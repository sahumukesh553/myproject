package com.virtusa.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.connection.DataBaseUtil;
import com.virtusa.model.Calender;
import com.virtusa.model.Lp;

public class LpDaoImpl implements LpDao {
	
 static Logger logger=Logger.getLogger(LpDaoImpl.class);
	@Override
	public boolean save(Lp lp) {
		boolean result=false;
		int value=0;
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String query="insert into lpmanagement_system.lp values(?,?,?,?,?,?,?,?)";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1,lp.getName());
			preparedStatement.setString(2,lp.getEmail());
			preparedStatement.setString(3,lp.getPassword());
			preparedStatement.setLong(4,lp.getMobile());
			preparedStatement.setString(5, lp.getProfession());
			preparedStatement.setString(6, lp.getCourse());
			preparedStatement.setString(7, lp.getAddress());
			preparedStatement.setString(8, lp.getGender());

		 value=preparedStatement.executeUpdate();
		 if(value>0)
		result=true;
		   
		} catch (ClassNotFoundException | SQLException e) {
			
			logger.error("Exception while enrolling lp ");
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return result;
	}
 
	@Override
	public boolean update(Lp lp) {
		boolean result=false;
		int value=0;
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String query="update lpmanagement_system.lp "
				+ "set name=?,password=?,mobile=?,profession=?,address=?"
				+ "where email=?";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1,lp.getName());
			preparedStatement.setString(2,lp.getPassword());
			preparedStatement.setLong(3,lp.getMobile());
			preparedStatement.setString(4, lp.getProfession());
			preparedStatement.setString(5, lp.getAddress());
			preparedStatement.setString(6,lp.getEmail());
			
		value=preparedStatement.executeUpdate();
		if(value>0)
			result=true;
} catch (ClassNotFoundException | SQLException e) {
			
			logger.error("Exception while updating lp ");
 			
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return result;
	}

public boolean varifyLogin(Lp lp) 
{boolean result=false;
	Connection connection=null;
PreparedStatement preparedStatement=null;
ResultSet resultset=null;
String query="select * from lpmanagement_system.lp where email=? and password=?";
try {
	connection=DataBaseUtil.getConnection();
	preparedStatement=connection.prepareStatement(query);
	
	preparedStatement.setString(1,lp.getEmail());
	preparedStatement.setString(2,lp.getPassword());
resultset	=preparedStatement.executeQuery();
result=resultset.next();
} catch (ClassNotFoundException | SQLException e) {
	
	e.printStackTrace();
	logger.error("Exception while verifying lp login ");
}    
finally
{
	try {
	preparedStatement.close();
	connection.close();}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
}
return result;
}

@Override
public List<Calender> viewCalender() {
	Connection connection=null;
	PreparedStatement preparedStatement=null;
	ResultSet resultset=null;
	List<Calender> list=new ArrayList();
	String query="select * from lpmanagement_system.calender";
	try {
		connection=DataBaseUtil.getConnection();
		preparedStatement=connection.prepareStatement(query);
resultset	=preparedStatement.executeQuery();

while(resultset.next())
{
String date=resultset.getString(1);
String topic=resultset.getString(2);
list.add(new Calender(date,topic));
}
	} 
	catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
			logger.error("Exception while view Calender");
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	return list;
}
}
