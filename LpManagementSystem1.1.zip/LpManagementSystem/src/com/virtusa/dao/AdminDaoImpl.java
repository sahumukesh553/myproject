package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.connection.DataBaseUtil;
import com.virtusa.model.Admin;
import com.virtusa.model.TrainingRoom;

public class AdminDaoImpl implements AdminDao{
	
	static Logger logger=Logger.getLogger(AdminDaoImpl.class);
	@Override
	
	
	
	  public boolean verifyLogin(Admin admin) {
		boolean result=false;
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultset=null;
		String query="select * from lpmanagement_system.admin where email=? and password=?";
		try {
			
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
			
			preparedStatement.setString(1,admin.getEmail());
			preparedStatement.setString(2,admin.getPassword());
	resultset	=preparedStatement.executeQuery();
	result=resultset.next();
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
			logger.error("Exception while verifying Admin login");
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	return result;
	}

	@Override
	public int bookVenue(TrainingRoom room) {
		int result=21;
		int value=0;
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultset=null;
		String query2="select room_status from lpmanagement_system.training_rooms where room_id=? and room_name=?";
		String query="update lpmanagement_system.training_rooms set room_status=? where room_id=? and room_name=?";
		try {
			
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
			preparedStatement1=connection.prepareStatement(query2);
			preparedStatement1.setInt(1,room.getRoomId());
			preparedStatement1.setString(2,room.getRoomName());
			 resultset=preparedStatement1.executeQuery();
			 if(resultset.next())
			 {
				if( resultset.getString("room_status").equals("booked")&&room.getRoomStatus().equals("booked"))
				{
					return 20;
				}
			 }
			 else {
				 return 21;
			 }
			preparedStatement.setString(1,room.getRoomStatus());
			preparedStatement.setInt(2,room.getRoomId());
			preparedStatement.setString(3,room.getRoomName());
			value=preparedStatement.executeUpdate();
			if(value>0)
				result=23;
		} catch (ClassNotFoundException | SQLException e) {
			
			logger.error("Exception while booking the room");
			return 22;
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return result;
	}

	@Override
	public boolean informMentor(String sub ,String password,String to,String from,String msg) {
		
		logger.info("message sent to mentor sucessfully");
		return  Mailer.send(from, password, to, sub, msg);
	}


}
