package com.virtusa.dao;

import java.util.List;

import com.virtusa.model.Admin;
import com.virtusa.model.TrainingRoom;

public interface AdminDao {
boolean verifyLogin(Admin admin);
int bookVenue(TrainingRoom room);
boolean informMentor(String sub, String password, String to, String from, String msg);
}
