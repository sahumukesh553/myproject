package com.virtusa.model;


public class Mentor {
	private	String name;
	private	String email;
	private	String password;
	private	long mobile;
	private	double salary;
	private	String gender;
	public Mentor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mentor(String name, String email, String password, long mobile, double salary, String gender) {
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobile = mobile;
		this.salary = salary;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Mentor [name=" + name + ", email=" + email + ", password=" + password + ", mobile=" + mobile
				+ ", salary=" + salary + ", gender=" + gender + "]";
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public String getPassword() {
		return password;
	}
	public long getMobile() {
		return mobile;
	}
	public double getSalary() {
		return salary;
	}
	public String getGender() {
		return gender;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
}
