package com.virtusa.controller.lp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.connection.DataBaseUtil;
import com.virtusa.dao.AdminDao;
import com.virtusa.dao.AdminDaoImpl;
import com.virtusa.dao.LpDao;
import com.virtusa.dao.LpDaoImpl;
import com.virtusa.model.Lp;
/*@WebServlet(
urlPatterns="/enroll",
loadOnStartup=1,
asyncSupported=true)*/
public class LpEnrollmentServlet extends HttpServlet {
	LpDao dao=new LpDaoImpl();
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();  
    if(req.getParameter("course").isEmpty()||req.getParameter("course")==null)
    {
    	req.setAttribute("message", "course details is not found");
    	req.getRequestDispatcher("/index.jsp").include(req, resp);
    	return;
    }
	       
	
	if(req.getParameter("mobile").chars().map(c -> c-'0').toArray().length!=10)
	{
		//out.print("<b>please Enter valid Mobile number</b>");
		req.getRequestDispatcher("WEB-INF/Enrollment.jsp").include(req, resp);
		return;
	}
	String course=req.getParameter("course");

	Lp lp=new Lp(req.getParameter("name"),req.getParameter("email"),Long.parseLong(req.getParameter("mobile")), req.getParameter("profession"),course, req.getParameter("address"),req.getParameter("gender"),req.getParameter("password"));
	
	if(dao.save(lp)) 
	{
		//out.print("<b>Successfully You Have Enrolled</b>");
		req.setAttribute("message", "you have enrolled successfully");
		req.getRequestDispatcher("/index.jsp").include(req, resp);
	}
	else
	{//out.print("<b>Something Went Wrong  When Enrolling You Please Try Again</b>");
		req.setAttribute("message", "this email id already present, please try with other email");
	req.getRequestDispatcher("/index.jsp").include(req, resp);
		
	}
	
	
	System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
	

}
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
	req.setAttribute("message", "you can not directy access this page");
	req.getRequestDispatcher("/index.jsp").forward(req, resp);
	
}
}
