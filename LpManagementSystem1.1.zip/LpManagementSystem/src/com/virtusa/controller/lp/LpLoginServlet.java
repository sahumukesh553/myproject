 package com.virtusa.controller.lp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.connection.DataBaseUtil;
import com.virtusa.dao.LpDao;
import com.virtusa.dao.LpDaoImpl;
import com.virtusa.model.Lp;

/*@WebServlet(urlPatterns="/lplogin"
)*/
public class LpLoginServlet extends HttpServlet {
	LpDao dao=new LpDaoImpl();
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
Lp lp=new Lp();
lp.setEmail(req.getParameter("email"));
	lp.setPassword(req.getParameter("password"));
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();  
	
if(dao.varifyLogin(lp))
{  HttpSession session=req.getSession(true);  
session.setAttribute("email",lp.getEmail()); 
req.setAttribute("message", "Welcome "+lp.getEmail());
//out.print("<b> Welcome to your profile "+lp.getEmail()+" </b>");
	req.getRequestDispatcher("WEB-INF/LpService.jsp").include(req, resp); 
}else {//out.print("<b>Sorry UserName or Password Error! Please Try Again</b>"); 
	req.setAttribute("message", "Sorry email or password is worng");
req.getRequestDispatcher("WEB-INF/lpLogin.jsp").include(req, resp); 
	 } 
	
	
System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
}
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
	req.getRequestDispatcher("WEB-INF/lpLogin.jsp").forward(req, resp); 
}
}
