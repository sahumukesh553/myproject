package com.virtusa.controller.mentor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.connection.DataBaseUtil;
import com.virtusa.dao.MentorDao;
import com.virtusa.dao.MentorDaoImpl;
import com.virtusa.model.Mentor;

/*@WebServlet(urlPatterns="/mentorlogin"
)*/
public class MentorLoginServlet extends HttpServlet {
	MentorDao dao=new MentorDaoImpl();
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
Mentor mentor=new Mentor();
	mentor.setEmail(req.getParameter("email"));
	mentor.setPassword(req.getParameter("password"));
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();  
	
if(dao.verifyLogin(mentor))
{HttpSession session=req.getSession(true);  
session.setAttribute("mentor",mentor.getEmail()); 
//out.print("<b> Welcome to your profile "+mentor.getEmail()+" </b>");
req.setAttribute("message", "Welcome "+mentor.getEmail());
	req.getRequestDispatcher("WEB-INF/mentorService.jsp").include(req, resp); 
}else {//out.print("<b>Sorry UserName or Password Error! Please try Again</b>"); 
	req.setAttribute("message", "Sorry Email or password is wrong");
req.getRequestDispatcher("WEB-INF/mentorLogin.jsp").include(req, resp); 
	 } 
	
	
System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
}
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
	req.getRequestDispatcher("WEB-INF/mentorLogin.jsp").forward(req, resp); 
}

}
