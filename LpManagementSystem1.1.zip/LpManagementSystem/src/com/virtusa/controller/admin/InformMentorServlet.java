package com.virtusa.controller.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.dao.AdminDao;
import com.virtusa.dao.AdminDaoImpl;

public class InformMentorServlet extends HttpServlet {
	AdminDao dao=new AdminDaoImpl();
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String from=req.getParameter("from");
	String password=req.getParameter("password");
	String to=req.getParameter("to");
	String subject=req.getParameter("subject");
	String message=req.getParameter("message");
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();
    HttpSession session=req.getSession(false); 
    if(session.getAttribute("name")!=null){  
          }  
          else{  
        	  req.setAttribute("message", "please login first");
              req.getRequestDispatcher("WEB-INF/adminLogin.jsp").include(req, resp);
              return;
          }  
  	
   
          
   if(dao.informMentor(from, password, to, subject, message))
   req.setAttribute("message", "Message sucessfully sent to mentor");
   else
	   req.setAttribute("message", "Message can not  sent to mentor");  
    //out.print("<b>message has been sent successfully to the mentor</b>");  
    req.getRequestDispatcher("WEB-INF/adminService.jsp").include(req, resp);
    System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
    out.close();  
}
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	 HttpSession session=req.getSession(false); 
	 try {
	    if(session.getAttribute("name")!=null){ 
	    	req.getRequestDispatcher("WEB-INF/informMentor.jsp").include(req, resp);
	          }  
	          else {
	        	  req.setAttribute("message", "please login first");
	              req.getRequestDispatcher("WEB-INF/adminLogin.jsp").include(req, resp);
	          }
	          }catch(Exception e)
	          {req.setAttribute("message", "please login first");
	        	  req.getRequestDispatcher("WEB-INF/adminLogin.jsp").include(req, resp);  
	          }
	 System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
	 }
	
		
	
}

