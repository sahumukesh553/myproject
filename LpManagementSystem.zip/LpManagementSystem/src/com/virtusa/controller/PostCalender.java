package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PostCalender extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String[] dates=req.getParameterValues("date");
		String[] topics=req.getParameterValues("topic");
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String query="insert into lpmanagement_system.calender values(?,?)";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
			connection.setAutoCommit(false);
			int value=0;
			for(int i=0;i<dates.length;i++)
			{
			preparedStatement.setString(1,dates[i]);
			preparedStatement.setString(2,topics[i]);
			preparedStatement.executeUpdate();
			value++;
			}
		
		if(value==dates.length) 
		{connection.commit();
			out.print("Successfully you have published calender ");
			req.getRequestDispatcher("/mentorService.jsp").include(req, resp);
		} 
		else
		{connection.rollback();
		out.print("Something went wrong  when publishing calender please try again");
		req.getRequestDispatcher("/mentorService.jsp").include(req, resp);
			
		}
		
		} catch (ClassNotFoundException | SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			out.print("Failed to publish calender- Date should not be duplicate please try with other Date");
			req.getRequestDispatcher("/postCalender.jsp").include(req, resp);
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		System.out.println("everything is working fine in publish calender");
		

	}
}
