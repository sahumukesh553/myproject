package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InformMentorServlet extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();  
      
   
          
   Mailer.SendMail();
    out.print("message has been sent successfully");  
    req.getRequestDispatcher("/adminService.jsp").include(req, resp);
   
    out.close();  
}
}
