package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/*@WebServlet(
urlPatterns="/enroll",
loadOnStartup=1,
asyncSupported=true)*/
public class LpEnrollmentServlet extends HttpServlet {
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String name=req.getParameter("nm");
	String email=req.getParameter("em");
	String password=req.getParameter("pass");
	long mobile=Long.parseLong(req.getParameter("mob"));
	String profession=req.getParameter("prof");
	String address=req.getParameter("add");
	String gender=req.getParameter("gender");
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();  
	Connection connection=null;
	PreparedStatement preparedStatement=null;
	String query="insert into lpmanagement_system.lp values(?,?,?,?,?,?,?)";
	try {
		connection=DataBaseUtil.getConnection();
		preparedStatement=connection.prepareStatement(query);
		preparedStatement.setString(1,name);
		preparedStatement.setString(2,email);
		preparedStatement.setString(3,password);
		preparedStatement.setLong(4,mobile);
		preparedStatement.setString(5, profession);
		preparedStatement.setString(6, address);
		preparedStatement.setString(7, gender);
		System.out.println(gender);
	int value=preparedStatement.executeUpdate();
	if(value>0) 
	{
		out.print("Successfully you have Enrolled");
		req.getRequestDispatcher("/home.jsp").include(req, resp);
	}
	else
	{out.print("Something went wrong  when enrolling you please try again");
	req.getRequestDispatcher("/home.jsp").include(req, resp);
		
	}
	
	} catch (ClassNotFoundException | SQLException e) {
		
		out.print("Enrollment Failed - This email Id already exists please try with other email id");
		req.getRequestDispatcher("/home.jsp").include(req, resp);
	}
	finally
	{
		try {
		preparedStatement.close();
		connection.close();}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	System.out.println("everything is working fine");
	

}
}
