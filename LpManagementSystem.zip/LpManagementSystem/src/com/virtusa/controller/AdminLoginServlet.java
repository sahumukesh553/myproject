package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*@WebServlet(urlPatterns="/lplogin"
)*/
public class AdminLoginServlet extends HttpServlet {
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	String email=req.getParameter("em");
	String password=req.getParameter("pass");
	resp.setContentType("text/html");  
    PrintWriter out = resp.getWriter();  
	Connection connection=null;
	PreparedStatement preparedStatement=null;
	ResultSet resultset=null;
	String query="select * from lpmanagement_system.admin where email=? and password=?";
	try {
		
		connection=DataBaseUtil.getConnection();
		preparedStatement=connection.prepareStatement(query);
		
		preparedStatement.setString(1,email);
		preparedStatement.setString(2,password);
resultset	=preparedStatement.executeQuery();
if(resultset.next())
{
	req.getRequestDispatcher("/adminService.jsp").forward(req, resp); 
}else {out.print("Sorry UserName or Password Error! please try again");  
req.getRequestDispatcher("/adminLogin.jsp").include(req, resp); 
	 } 
	
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	finally
	{
		try {
		preparedStatement.close();
		connection.close();}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	System.out.println("everything is working fine");
}

}
