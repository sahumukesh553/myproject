package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//@WebServlet(urlPatterns="/viewCalender")
public class ViewCalender extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultset=null;
		String query="select * from lpmanagement_system.calender";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
	resultset	=preparedStatement.executeQuery();
	List<Calender> list=new ArrayList();
	int count=0;
	while(resultset.next())
	{
	String date=resultset.getString(1);
	String topic=resultset.getString(2);
	System.out.println(date+" "+topic);
	list.add(new Calender(date,topic));
	count++;
	}
	
	if(count>0)
	{
		req.setAttribute("data", list); 
		req.getRequestDispatcher("/viewCalender.jsp").forward(req, resp); 
	}
	else  {
	out.print("No calender Details Found Please try again later !");
		req.getRequestDispatcher("/LpService.jsp").include(req, resp); 
	}
		
		} 
	catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		System.out.println("everything is working view");
	}

}
