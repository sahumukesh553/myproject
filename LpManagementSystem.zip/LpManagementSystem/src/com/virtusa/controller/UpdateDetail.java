package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//@WebServlet(urlPatterns="/update")
public class UpdateDetail extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("nm");
		String newEmail=req.getParameter("em1");
		String oldEmail=req.getParameter("em2");
		String password=req.getParameter("pass");
		long mobile=Long.parseLong(req.getParameter("mob"));
		String profession=req.getParameter("prof");
		String address=req.getParameter("add");
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String query="update lpmanagement_system.lp "
				+ "set name=?,email=?,password=?,mobile=?,profession=?,address=?"
				+ "where email=?";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1,name);
			preparedStatement.setString(2,newEmail);
			preparedStatement.setString(3,password);
			preparedStatement.setLong(4,mobile);
			preparedStatement.setString(5, profession);
			preparedStatement.setString(6, address);
			preparedStatement.setString(7, oldEmail);
			System.out.println("oldmail "+oldEmail);
		int value=preparedStatement.executeUpdate();
		System.out.println(" row updated "+value);
		if(value>0)
		{
		out.print("Details updated successfully");
		req.getRequestDispatcher("/LpService.jsp").include(req, resp);
		}
		else
		{out.print(" Can not update detail please enter right  old Email Id");
		req.getRequestDispatcher("/update.jsp").include(req, resp);
		}
		
		} catch (ClassNotFoundException | SQLException e) {
			
			out.print(" This new Email id already exist please try again with other email !");
			req.getRequestDispatcher("/update.jsp").include(req, resp);
			
		}
		finally
		{
			try {
			preparedStatement.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		System.out.println("everything is working fine");
		

	}
}
