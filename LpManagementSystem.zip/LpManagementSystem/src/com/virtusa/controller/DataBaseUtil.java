package com.virtusa.controller;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DataBaseUtil {
public static Connection getConnection() throws ClassNotFoundException, SQLException {

	FileReader reader=null;
	 Properties p=null;

	try {
		
		reader = new FileReader("C:\\Users\\INDIA\\Desktop\\MyProject\\LpManagementSystem\\src\\database.properties");
     p=new Properties();  
    p.load(reader);  
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		Class.forName(p.getProperty("driver"));
	final	Connection	connection=DriverManager.getConnection(p.getProperty("url"),p.getProperty("user"),p.getProperty("password"));

		
	return connection;
}
}
