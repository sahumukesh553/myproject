package com.virtusa.controller;

public class Calender {
private String date;
private String topic;
public String getDate() {
	return date;
}
public String getTopic() {
	return topic;
}
public Calender(String date, String topic) {
	this.date = date;
	this.topic = topic;
}
public Calender()
{
	
}
@Override
public String toString() {
	return "Calender [date=" + date + ", topic=" + topic + "]";
}


}
