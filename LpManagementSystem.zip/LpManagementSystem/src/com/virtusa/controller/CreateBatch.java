package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CreateBatch extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int batchId=Integer.parseInt(req.getParameter("bid"));
		String batchName=req.getParameter("bname");
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
		Connection connection=null;
		PreparedStatement preparedStatement1=null;
		PreparedStatement preparedStatement2=null;
		PreparedStatement preparedStatement3=null;
		ResultSet resultset=null;
		String query1="select * from lpmanagement_system.lp";
		String query2="insert into lpmanagement_system.batch_detail values(?,?,?,?,?,?,?)";
		String query3="insert into lpmanagement_system.batch values(?,?) ";
		try {
			connection=DataBaseUtil.getConnection();
			preparedStatement1=connection.prepareStatement(query1);
			preparedStatement2=connection.prepareStatement(query2);
			preparedStatement3=connection.prepareStatement(query3);
			connection.setAutoCommit(false);
	resultset	=preparedStatement1.executeQuery();
	System.out.println(" select qury"+resultset);
	List<Lp> list=new ArrayList();
	int count=0;
	while(resultset.next())
	{
String name=resultset.getString("name");
String email=resultset.getString("email");
long mobile=resultset.getLong("mobile");
String profession=resultset.getString("profession");
String address=resultset.getString("address");
String gender=resultset.getString("gender");
list.add(new Lp(name, email, mobile, profession, address, gender,batchId));
System.out.println(list.get(count));
	count++;
	}
	preparedStatement3.setInt(1, batchId);
	preparedStatement3.setString(2, batchName);
	preparedStatement3.executeUpdate();
	int count2=0;
	for (Lp lp : list) {
		preparedStatement2.setString(1,lp.getName());
		preparedStatement2.setString(2,lp.getEmail());
		preparedStatement2.setLong(3,lp.getMobile());
		preparedStatement2.setString(4,lp.getProfession());
		preparedStatement2.setString(5,lp.getAddress());
		preparedStatement2.setString(6,lp.getGender());
		preparedStatement2.setInt(7,lp.getBatchId());
		preparedStatement2.executeUpdate();
		count2++;
		
	}
	
	if(count==count2)
	{connection.commit();
		out.print("Batch has been created successfully !");
		req.getRequestDispatcher("/mentorService.jsp").include(req, resp); 
	}
	else  {
		connection.rollback();
	out.print("error while creating Batch!");
		req.getRequestDispatcher("/mentorService.jsp").include(req, resp); 
	}
		
		} 
	catch (ClassNotFoundException | SQLException e) {
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		out.print("Exception while creating Batch  !");
		req.getRequestDispatcher("/mentorService.jsp").include(req, resp); 
			
		}
		finally
		{
			try {
			preparedStatement1.close();
			preparedStatement2.close();
			connection.close();}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		System.out.println("everything is working fine in create batch");
	}

}
