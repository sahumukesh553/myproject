package com.virtusa.controller;

public class Lp {
private	String name;
private	String email;
private	long mobile;
private	String profession;
private	String address;
private	String gender;
private int batchId;

@Override
public String toString() {
	return "Lp [name=" + name + ", email=" + email + ", mobile=" + mobile + ", profession=" + profession + ", address="
			+ address + ", gender=" + gender + ", batchId=" + batchId + "]";
}
public int getBatchId() {
	return batchId;
}
public Lp(String name, String email, long mobile, String profession, String address, String gender, int batchId) {
	this.name = name;
	this.email = email;
	this.mobile = mobile;
	this.profession = profession;
	this.address = address;
	this.gender = gender;
	this.batchId = batchId;
}
public String getName() {
	return name;
}
public String getEmail() {
	return email;
}
public long getMobile() {
	return mobile;
}
public String getProfession() {
	return profession;
}
public String getAddress() {
	return address;
}
public String getGender() {
	return gender;
}

}
