package com.virtusa.controller.mentor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.dao.MentorDao;
import com.virtusa.dao.MentorDaoImpl;
import com.virtusa.model.Calender;

public class PostCalender extends HttpServlet {
	MentorDao dao=new MentorDaoImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String[] dates=req.getParameterValues("date");
		String[] topics=req.getParameterValues("topic");
		System.out.println(Arrays.toString(dates)+" "+Arrays.toString(topics));
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
	    HttpSession session=req.getSession(false);  
	    if(session.getAttribute("mentor")!=null){  
	     
	        }  
	        else{  
	        	req.setAttribute("message", "please login first");
	            req.getRequestDispatcher("WEB-INF/mentorLogin.jsp").include(req, resp);
	            return;
	        }  
	    if(dao.publishCalender(dates, topics)) 
		{
			//out.print("<b>Successfull You Have Published Calender </b>");
	    	req.setAttribute("message", "calender published successfully");
			req.getRequestDispatcher("WEB-INF/mentorService.jsp").include(req, resp);
		} 
		else
		{
		//out.print("<b>Something Went Wrong  When Publishing Calender Please Try Again</b>");
			req.setAttribute("message", "calender can not be published! it seems date is duplicate date");
		req.getRequestDispatcher("WEB-INF/mentorService.jsp").include(req, resp);
			
		}
	    System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());

	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 HttpSession session=req.getSession(false); 
		 System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
		 try {
		    if(session.getAttribute("mentor")!=null)
		    {
		    	Date date=new Date();
			SimpleDateFormat simple=new SimpleDateFormat("yyyy-MM-dd");
			String format = simple.format(date);
			req.setAttribute("date", format);
		    	req.getRequestDispatcher("WEB-INF/postCalender.jsp").forward(req, resp); 
		 }
		        else {req.setAttribute("message", "please login first");
		            req.getRequestDispatcher("WEB-INF/mentorLogin.jsp").include(req, resp);
		            
		        }
		    }catch(Exception e)
		    {req.setAttribute("message", "please login first");
		    	 req.getRequestDispatcher("WEB-INF/mentorLogin.jsp").include(req, resp);
		    }
		
	}
}
