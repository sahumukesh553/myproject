package com.virtusa.controller.mentor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.dao.MentorDao;
import com.virtusa.dao.MentorDaoImpl;
import com.virtusa.model.BatchDetail;
import com.virtusa.model.Lp;

public class CreateBatch extends HttpServlet{
	MentorDao dao=new MentorDaoImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		BatchDetail batch=new BatchDetail();
		batch.setBatchId(Integer.parseInt(req.getParameter("batchId")));
		batch.setBatchName(req.getParameter("batchName"));
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter(); 
	    HttpSession session=req.getSession(false);  
	    if(session.getAttribute("mentor")!=null){  
	   
	        }  
	        else{  
	        	req.setAttribute("message", "please login first");
	            req.getRequestDispatcher("WEB-INF/mentorLogin.jsp").include(req, resp);
	            return;
	        }  
	    int result=dao.createBatch(batch);
	    HashMap<Integer,String> message=new HashMap();
	    message.put(0,"Sorry batch name already exist please enter another");
	    message.put(1,"No new trainee exist");
	    message.put(2,"Batch id already present try other one");
	    message.put(3,"Batch has been created successfully !");
	    
			//out.print("<b> "+message.get(result)+" </b>");
	    req.setAttribute("message", message.get(result));
			req.getRequestDispatcher("WEB-INF/mentorService.jsp").include(req, resp); 
		
			System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
	}
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	HttpSession session=req.getSession(false);
	try {
    if(session.getAttribute("mentor")!=null){  
    	req.getRequestDispatcher("WEB-INF/createBatch.jsp").forward(req, resp); 
        }  
        else{  
        	req.setAttribute("message", "please login first");
            req.getRequestDispatcher("WEB-INF/mentorLogin.jsp").include(req, resp);
           
        }  
	}catch(Exception e)
	{req.setAttribute("message", "please login first");
		req.getRequestDispatcher("WEB-INF/mentorLogin.jsp").include(req, resp);}
	System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
}
}
