package com.virtusa.controller.lp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.virtusa.dao.LpDao;
import com.virtusa.dao.LpDaoImpl;
import com.virtusa.model.Calender;
//@WebServlet(urlPatterns="/viewCalender")
public class ViewCalender extends HttpServlet{
	LpDao dao=new LpDaoImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter();  
	    HttpSession session=req.getSession(false);
	    try {
	    if(session.getAttribute("email")!=null){  
	      String username= (String) session.getAttribute("email");  
	       
	        }  
	        else{  
	        	req.setAttribute("message", "please login first");
	            req.getRequestDispatcher("WEB-INF/lpLogin.jsp").include(req, resp);
	            return;
	        } }
	    catch(Exception e)
	    {
	    	req.getRequestDispatcher("WEB-INF/lpLogin.jsp").include(req, resp);
            return;
	    }
		List<Calender> list=dao.viewCalender();
	if(!list.isEmpty())
	{
		req.setAttribute("data", list); 
		req.getRequestDispatcher("WEB-INF/viewCalender.jsp").forward(req, resp); 
	}
	else  {
	//out.print("No calender Details Found Please try again later !");
		req.setAttribute("message", "Sorry calender not published now try again later");
		req.getRequestDispatcher("WEB-INF/LpService.jsp").include(req, resp); 
	}
		
		
	System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName()+" "+req.getMethod());
	}

}
