package com.virtusa.controller.lp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.model.Lp;
@WebServlet(urlPatterns="/web")
public class WebDevelopment extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	
		req.setAttribute("course","Web Development");
		System.out.println("Web Development");
		req.getRequestDispatcher("WEB-INF/Enrollment.jsp").forward(req, resp); 
		System.out.println("everything is working fine "+req.getServletPath()+" "+req.getServerName());
		
	}

}
