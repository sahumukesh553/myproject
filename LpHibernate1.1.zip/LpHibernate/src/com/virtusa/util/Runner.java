package com.virtusa.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Runner {

	public static void main(String[] args) {
		//HibernateUtil.getFactory();
		
	}

}
