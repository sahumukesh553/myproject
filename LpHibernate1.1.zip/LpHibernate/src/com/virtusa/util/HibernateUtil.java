package com.virtusa.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	//1 create a static variable
		private static SessionFactory factory=null;
	static	{
			Configuration configuration=new Configuration();
			configuration.configure();
			factory=configuration.buildSessionFactory();
		}
	public static SessionFactory getFactory() {
		return factory;
	}
	private HibernateUtil() {
		super();
		// TODO Auto-generated constructor stub
	}
}
