package com.virtusa.dao;

import java.util.List;

import com.virtusa.model.Calender;
import com.virtusa.model.Lp;

public interface LpDao {
	boolean save(Lp lp);
 boolean varifyLogin(Lp lp);
 List<Calender> viewCalender();
boolean update(Lp lp);
	
	

}
