package com.virtusa.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import com.virtusa.model.Admin;
import com.virtusa.model.TrainingRoom;
import com.virtusa.util.HibernateUtil;

public class AdminDaoImpl implements AdminDao{
	
	
	@Override
	public boolean verifyLogin(Admin admin) {
		boolean result=false;
		 Session session=null;
		    String query1="from Admin where email = :email and password = :password";
		try {
				 
				SessionFactory factory=HibernateUtil.getFactory();
				 
				session=factory.openSession();
				 Transaction transaction=session.beginTransaction();
				 Query query=session.createQuery(query1);
				  query.setParameter("email", admin.getEmail());
				  query.setParameter("password", admin.getPassword());
				  List<Admin> list=query.list();
		result=!list.isEmpty();
			} catch (Exception e) {
					e.printStackTrace();
			}
		
			finally  
			
			{
				 session.close();
			}
	return result;
	}  

	@Override
	public int bookVenue(TrainingRoom room) {
		Session session=null;
		int result=21;
		String query2="from TrainingRoom where roomId=? and roomName=?";
		String query="update TrainingRoom set roomStatus= :roomStatus where roomId= :roomId and roomName= :roomName";
		try {
			SessionFactory factory=HibernateUtil.getFactory();
			  session=factory.openSession();
			 Transaction transaction=session.beginTransaction();
			 Query hql=session.createQuery(query2);
			 hql.setParameter(0, room.getRoomId());
			 hql.setParameter(1, room.getRoomName());
			 List<TrainingRoom> list=hql.list();
			 if(!list.isEmpty()&&list!=null)
			 { 
			 if(list.get(0).getRoomStatus().equals("booked") && room.getRoomStatus().equals("booked") )
				 return 20;
			 }else
			 {
				 return 21;
			 }
			Query query1=session.createQuery(query);
			query1.setParameter("roomStatus",room.getRoomStatus());
			query1.setParameter("roomId",room.getRoomId());
			query1.setParameter("roomName",room.getRoomName());
	int value=query1.executeUpdate();
	if(value>0)
	{result=23;
	transaction.commit();
	}
		
		} catch (Exception e) {
			return 22;
		}
		finally
		{
		session.close();
		}
		return result;
	

	}

	@Override
	public boolean informMentor(String sub ,String password,String to,String from,String msg) {
		
		return Mailer.send(from, password, to, sub, msg);
	}


}
