package com.virtusa.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import com.virtusa.model.Calender;
import com.virtusa.model.Lp;
import com.virtusa.util.HibernateUtil;

public class LpDaoImpl implements LpDao {
	

	@Override
	public boolean save(Lp lp) {
		
	boolean result=false;
		 Session session=null;
		    try {
			 SessionFactory factory=HibernateUtil.getFactory();
			  session=factory.openSession();
			 Transaction transaction=session.beginTransaction();
			
			 session.persist(lp);
			 transaction.commit();
			 result=true;
		    } catch (Exception e) {
				e.printStackTrace();
		    }
			finally
			{
				session.close();
			}
			return result;
			
	}

	@Override
	public boolean update(Lp lp) {
	boolean	result=false;
		Session session=null;
		String query1="update Lp "
				+ "set name=?,password=?,mobile=?,profession=?,address=?"
				+ "where email=?";
		try {
			SessionFactory factory=HibernateUtil.getFactory();
			  session=factory.openSession();
			 Transaction transaction=session.beginTransaction();
			 
	Query query=session.createQuery(query1);
			query.setString(0,lp.getName());
			query.setString(1,lp.getPassword());
			query.setLong(2,lp.getMobile());
			query.setString(3, lp.getProfession());
			query.setString(4, lp.getAddress());
			query.setString(5,lp.getEmail());
			
		int value=query.executeUpdate();
		System.out.println(" row updated "+value);
		if(value>0)
		{
		result=true;
		}
		
		
		} catch (Exception e) {
			
			
		}
		finally
		{
			session.close();
		}
		return result;
	}

public boolean varifyLogin(Lp lp) 
{boolean result=false;
Session session=null;
String query1="from Lp where email= :email and password= :password";
try {
	
	SessionFactory factory=HibernateUtil.getFactory();
	  session=factory.openSession();
	 Transaction transaction=session.beginTransaction();
	 Query query=session.createQuery(query1);
	 query.setParameter("email", lp.getEmail());
	 query.setParameter("password", lp.getPassword());
	 List<Lp> list=query.list();
if(list.size()>0)
{
result=true;
}

} catch (Exception e) {
	
	e.printStackTrace();
}
finally
{
	session.close();
}
return result;
}

@Override
public List<Calender> viewCalender() {
	Session session=null;
	List<Calender> list=new ArrayList();
	String query="from Calender";
	try {
		SessionFactory factory=HibernateUtil.getFactory();
		  session=factory.openSession();
		 Transaction transaction=session.beginTransaction();
		 Query query1=session.createQuery(query);
list=query1.list();
	
	} 
catch (Exception e) {
		
		e.printStackTrace();
	}
	finally
	{
		session.close();
	}
	return list;
}
}
