package com.virtusa.dao;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import com.virtusa.model.*;
import com.virtusa.util.HibernateUtil;

public class MentorDaoImpl implements MentorDao {



	@Override
	public boolean verifyLogin(Mentor mentor) {
		boolean result=false;
		Session session=null;
	    String query1="from Mentor where email=? and password=?";
	try {
			
			SessionFactory factory=HibernateUtil.getFactory();
			  session=factory.openSession();
			 Transaction transaction=session.beginTransaction();
			 Query query=session.createQuery(query1);
			 query.setString(0, mentor.getEmail());
			 query.setString(1, mentor.getPassword());
			 List<Mentor> list=query.list();
	if(list.size()>0)
	{result=true;
	}
		
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		finally
		{
			session.close();
		}
	return result;
	}

	@Override
	public int createBatch(BatchDetail batch) {
		System.out.println(batch);
	
		Session session=null;
		Transaction transaction=null;
		String query1 ="from Lp";
		String query2 ="select batchName from BatchDetail";
		String query3 ="select email from Trainee";
		
		try {
			SessionFactory factory=HibernateUtil.getFactory();
			  session=factory.openSession();
			  transaction=session.beginTransaction();
			  Query hql2=session.createQuery(query2);
			  List<String> batchNames=hql2.list();
			  if(batchNames.contains(batch.getBatchName()))
			  {
				  return 0;
			  }
			  Query hql3=session.createQuery(query3);
			  List<String> traineeEmails=hql3.list();  
	Query hql1=session.createQuery(query1);
	List<Lp> list=hql1.list();
	System.out.println("list size"+list.size());
	List<Trainee> trainees=new ArrayList();
	
	for (Lp lp : list) {
		if(traineeEmails.contains(lp.getEmail()))
			continue;
		String name=lp.getName();
		String email=lp.getEmail();
		long mobile=lp.getMobile();
		String profession=lp.getProfession();
		String address=lp.getAddress();
		String gender=lp.getGender();
		String course=lp.getCourse();
		
		trainees.add(new Trainee(name, email, mobile, profession,course, address, gender));
		
	}
	if(trainees.isEmpty())
	{
		return 1;
	}
	batch.setTrainee(trainees);
	session.save(batch);
	
	
	transaction.commit();
	
		
		} 
	catch (Exception  e) {
		e.printStackTrace();
		transaction.rollback();
		return 2;
		
		}
		finally
		{
			session.close();
		}
		return 3;
	}

	@Override
	public boolean publishCalender(String[] dates,String []topics) {
		boolean result=false;
		 Session session=null;
		    Transaction transaction=null;
			
			try {
				SessionFactory factory=HibernateUtil.getFactory();
			 session=factory.openSession();
			 transaction=session.beginTransaction();
			 int count=0;
			 for (int i=0;i<dates.length;i++) {
				session.persist(new Calender(dates[i], topics[i]));
				count++;
				
			}
			
			
			if(dates.length==count)
			{
				result=true;
				transaction.commit();
			} 
			else
			{ transaction.rollback();
			
			}
			
			} catch (Exception e) {
				e.printStackTrace();
				 transaction.rollback();
				
			}
			finally
			{
				session.close();
			}
		return result;
	}
	

}
