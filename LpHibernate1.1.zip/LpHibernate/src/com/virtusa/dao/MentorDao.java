package com.virtusa.dao;

import java.util.List;

import com.virtusa.model.BatchDetail;
import com.virtusa.model.Calender;
import com.virtusa.model.Mentor;

public interface MentorDao {
boolean verifyLogin(Mentor mentor);
int createBatch(BatchDetail batch);
boolean publishCalender(String[] dates, String[] topics);
}
