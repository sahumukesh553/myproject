package com.virtusa.model;

public class Mail {
private String from;
private String to;
private String subject;
private String message;
private String password;
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "Mail [from=" + from + ", to=" + to + ", subject=" + subject + ", message=" + message + ", password="
			+ password + "]";
}
public String getFrom() {
	return from;
}
public String getTo() {
	return to;
}
public String getSubject() {
	return subject;
}
public String getMessage() {
	return message;
}
public void setFrom(String from) {
	this.from = from;
}
public void setTo(String to) {
	this.to = to;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public void setMessage(String message) {
	this.message = message;
}

}
