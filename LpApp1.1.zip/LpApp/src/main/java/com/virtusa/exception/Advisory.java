package com.virtusa.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice(basePackages="com.virtusa.controller")
public class Advisory {
	@ExceptionHandler(value= {RuntimeException.class})
	public String exceptionHandle()

	{
		return "errorPage";
	}

}
