package com.virtusa.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.virtusa.MyLogger;
import com.virtusa.dao.AdminDao;
import com.virtusa.dao.AdminDaoImpl;
import com.virtusa.dao.LpDao;
import com.virtusa.dao.LpDaoImpl;
import com.virtusa.model.Admin;
import com.virtusa.model.Lp;
import com.virtusa.model.Mail;
import com.virtusa.model.TrainingRoom;

@Controller
public class AdminController {
	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	AdminDao dao=(AdminDaoImpl) context.getBean("adminDao");
	@RequestMapping("adminlogin")
	public String login()
	{
		return "adminLogin";
	}
	@RequestMapping(value="adminlogin",method=RequestMethod.POST)
	public String loginSucess(@ModelAttribute Admin admin,HttpSession session,Model model)
	{
		MyLogger.logger.info("LOGIN Status");
		MyLogger.logger.info(admin);
		
		if(dao.verifyLogin(admin))
		{
			MyLogger.logger.info(" pass in login");
			session.setAttribute("admin",admin.getEmail() );
			model.addAttribute("message","Welcome "+admin.getEmail()+" to your profile");
			return "adminService";
		}
		else {
			MyLogger.logger.info("account not found");
		model.addAttribute("message","please Enter correct email or password");
	return "adminLogin";
		}
	}
	@RequestMapping("bookroom")
	public String bookRoom(HttpSession session,Model model)
	{
		try {
		    if(session.getAttribute("admin")!=null){  
		    	return "bookRoom";
		        }  
		        else{  model.addAttribute("message", "please login first");
		            
		           return "adminLogin";
		        } }
		 catch(Exception e)
		 { model.addAttribute("message", "please login first");
		 return "adminLogin";}
		
	}
	
	
	@RequestMapping(value="bookroom",method=RequestMethod.POST)
	public String booking(@ModelAttribute TrainingRoom room,HttpSession session,Model model) 
	{
		 if(session.getAttribute("admin")!=null){  
		    	
		        }  
		        else{  model.addAttribute("message", "please login first");
		            
		           return "adminLogin";
		        }
		int result=dao.bookVenue(room);
		HashMap<Integer,String> hs=new HashMap();
		hs.put(20,"Sorry room is already booked");
		hs.put(21,"Room is not found");
		hs.put(22,"Exception while booking room");
		hs.put(23,"Room Has "+room.getRoomStatus()+" successfully");

		if(result==23)
		{model.addAttribute("message",hs.get(result));
			return "adminService";
		}
		else
		{model.addAttribute("message",hs.get(result));
			return "bookRoom";
		}
		
		
		
	}
	@RequestMapping(value="sendmail")
	public String informPage(HttpSession session,Model model) 
	{
		try {
		    if(session.getAttribute("admin")!=null){ 
		    	return "informMentor";
		          }  
		          else {
		        	  model.addAttribute("message", "please login first");
		              return "adminLogin";
		          }
		          }catch(Exception e)
		          {model.addAttribute("message", "please login first");
	              return "adminLogin";
		          }
	}
	@RequestMapping(value="sendmail",method=RequestMethod.POST)
	public String inform(@ModelAttribute Mail mail,Model model) 
	{if(dao.informMentor(mail))
   model.addAttribute("message","mail sucessufully sent to mentor");
	else
		model.addAttribute("message"," something went wrong while sending mail  to mentor");
					return "adminService";
	}
		
		
	
	
	
}
