package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.virtusa.MyLogger;
import com.virtusa.dao.*;
import com.virtusa.dao.LpDaoImpl;
import com.virtusa.model.Calender;
import com.virtusa.model.Lp;

@Controller
public class LpController{
	
ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
LpDao dao=(LpDaoImpl) context.getBean("lpDao");
@RequestMapping("/lplogin")
public String login(HttpSession session)
{MyLogger.logger.info("LOGIN form for lp");
	return "lpLogin";
}
@RequestMapping(value="/lplogin",method=RequestMethod.POST)
public String loginSucess(@ModelAttribute Lp lp,HttpSession session,Model model)
{
	MyLogger.logger.info("LOGIN Status of lp");
	MyLogger.logger.info(lp);
	
	if(dao.varifyLogin(lp))
	{
		MyLogger.logger.info(" pass in login");
		session.setAttribute("email",lp.getEmail());
		model.addAttribute("message", " Welcome  "+lp.getEmail()+" to your profile");
		return "LpService";
	}
	else {
		MyLogger.logger.info("else excute");
	model.addAttribute("message","please Enter correct email or password");
return "lpLogin";
	}
}
@RequestMapping(value="/web")
public String enrollWeb(Model model)
{
	MyLogger.logger.info("Web Developer");
	model.addAttribute("course", "Web Developer");
	
	return "Enrollment";
	
}
@RequestMapping(value="/fullStack")
public String enrollFullStack(Model model)
{
	MyLogger.logger.info("Full Stack Developer");
	model.addAttribute("course", "Full Stack Developer");
	
	return "Enrollment";
	
}
@RequestMapping(value="/testing")
public String enrollTesting(Model model)
{
	MyLogger.logger.info("Automation Testing");
	model.addAttribute("course", "Automation Testing");
	
	return "Enrollment";
	
}

@RequestMapping(value="/update")
public String update(HttpSession session,Model model)
{try {
	if(session.getAttribute("email")!=null && session!=null)
		return "update";
	else
	{model.addAttribute("message", "please login first");
	return "lpLogin";
	}
	}catch(Exception e)
	{model.addAttribute("message", "please login first");
		return "lpLogin";
		
	}
	
}
@RequestMapping(value="/enroll")
public String enroll(Model model)
{model.addAttribute("message","you can not directly access this page");
	return "index";

}
@RequestMapping(value="/enroll",method=RequestMethod.POST)
public String signUp(@ModelAttribute Lp lp,Model model)
{
	if(lp.getCourse()==null)
	{model.addAttribute("message","course details not found");
		return "index";
	}
	
	MyLogger.logger.info(lp.getMobile());
	MyLogger.logger.info(lp.getName());
	if(lp.getName()==null)
{
		throw new RuntimeException();
}
	
	if(Long.toString(lp.getMobile()).chars().map(c -> c-'0').toArray().length!=10)
	{model.addAttribute("message","please enter 10 digit mobile number");
		return "index";
	}
	try {
	dao.save(lp);
	}
	catch(Exception e)
	{
		model.addAttribute("message","This email id already exist");
		return "index";
	}
	List<Lp> list=dao.list();
	
	model.addAttribute("list",list);
	model.addAttribute("message","you have enrolled sucessfully");
	return "index";
	
}
@RequestMapping(value="/update",method=RequestMethod.POST)
public String updateRecord(@ModelAttribute Lp lp,Model model,HttpSession session)
{
MyLogger.logger.info(lp.getEmail());
	
	
	MyLogger.logger.info(lp.getMobile());
	MyLogger.logger.info(" length "+Long.toString(lp.getMobile()).chars().map(c -> c-'0').toArray().length);
	if(Long.toString(lp.getMobile()).chars().map(c -> c-'0').toArray().length!=10)
	{model.addAttribute("message","please enter 10 digit mobile number");
		return "update";
	}
	if(session.getAttribute("email")!=null && session!=null)
	{
		String email=(String) session.getAttribute("email");
		lp.setEmail(email);
	}
	else
	{model.addAttribute("message", "please login first");
	return "lpLogin";
	}
	try
	{
	dao.update(lp);
	}catch(Exception e)
	{
		model.addAttribute("message","Exception while updating");
		return "LpService";
	}
	
	model.addAttribute("message",lp.getEmail()+" your record has been updated");
	return "LpService";
	
}



@RequestMapping(value="viewCalender")
public String logout(Model model,HttpSession session) 
{
	try {
	    if(session.getAttribute("email")!=null){  
	      String username= (String) session.getAttribute("email");  
	       
	        }  
	        else{  
	        	model.addAttribute("message", "please login first");
	           return "lpLogin";
	        } }
	    catch(Exception e)
	    {
	    	model.addAttribute("message", "please login first");
	           return "lpLogin";
	    }
	List<Calender> list=dao.viewCalender();
	System.out.println(list);
	
	
	if(list.isEmpty())
	{
		model.addAttribute("message","Calender not published right now check after some time");
		return "LpService";
	}
	model.addAttribute("data",list);
	return "viewCalender";

}
//@ExceptionHandler(value= {RuntimeException.class,NullPointerException.class})
//public String exceptionHandle()
//
//{
//	return "errorPage";
//}

}
