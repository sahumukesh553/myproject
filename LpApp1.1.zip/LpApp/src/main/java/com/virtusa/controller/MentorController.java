package com.virtusa.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.MyLogger;
import com.virtusa.dao.LpDao;
import com.virtusa.dao.LpDaoImpl;
import com.virtusa.dao.MentorDao;
import com.virtusa.dao.MentorDaoImpl;
import com.virtusa.model.BatchDetail;
import com.virtusa.model.Lp;
import com.virtusa.model.Mentor;

@Controller
public class MentorController {
	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	MentorDao dao=(MentorDaoImpl) context.getBean("mentorDao");
	@RequestMapping("mentorlogin")
	public String login()
	{
		return "mentorLogin";
	}
	@RequestMapping(value="mentorlogin",method=RequestMethod.POST)
	public String loginSucess(@ModelAttribute Mentor mentor,HttpSession session,Model model)
	{
		MyLogger.logger.info("LOGIN Status");
		MyLogger.logger.info(mentor);
		
		if(dao.verifyLogin(mentor))
		{
			MyLogger.logger.info(" pass in login");
			session.setAttribute("mentor",mentor.getEmail());
			model.addAttribute("message","Welcome "+mentor.getEmail()+" to your profile");
			return "mentorService";
		}
		else {
			MyLogger.logger.info("else excute");
		model.addAttribute("message","please Enter correct email or password");
	return "mentorLogin";
		}
	}
		
		@RequestMapping(value="createbatch")
		public String createBatchPage(HttpSession session,Model model) 
		{try {
		    if(session.getAttribute("mentor")!=null){  
		    	return "createBatch";
		        }  
		        else{  
		        	model.addAttribute("message", "please login first"); 
		            return "mentorLogin";
		           
		        }  
			}catch(Exception e)
			{model.addAttribute("message", "please login first"); 
            return "mentorLogin";}

		}
		@RequestMapping(value="postcalender")
		public String postCalenderPage(HttpSession session,Model model) 
		{
			 try {
				    if(session.getAttribute("mentor")!=null) {
				    	Date date=new Date();
						SimpleDateFormat simple=new SimpleDateFormat("yyyy-MM-dd");
						String format = simple.format(date);
						MyLogger.logger.info("Today date "+format);
						model.addAttribute("date", format);
						return "postCalender";

				 }
				        else {model.addAttribute("message", "please login first");
				           return "mentorLogin";
				        }
				    }catch(Exception e)
				    {model.addAttribute("message", "please login first");
			           return "mentorLogin";}
			
		}
		@RequestMapping(value="createbatch",method=RequestMethod.POST)
		public String createBatch(@ModelAttribute BatchDetail batch,HttpSession session,Model model) 
		{int result=dao.createBatch(batch);
				HashMap<Integer,String> hs=new HashMap();
		hs.put(0, "Batch id already present ");
		hs.put(1, "Batch name already present");
		hs.put(2, "No found trainee to create batch");
		hs.put(3, "Batch created successfully");
			
			
				model.addAttribute("message", hs.get(result));
				return "mentorService";
			
		

		}
		@RequestMapping(value="postcalender",method=RequestMethod.POST)
		public String postCalender(@RequestParam("date") String[] date,@RequestParam("topic") String[] topic,HttpSession session,Model model) 
		{if(dao.publishCalender(date,topic))
		{model.addAttribute("message", "calender published sucessfully");
		return "mentorService";
		}else
		{
			model.addAttribute("message", "something went wrong while publishing calender please try again");
			return "postCalender";
		}
			

		}
	
}
