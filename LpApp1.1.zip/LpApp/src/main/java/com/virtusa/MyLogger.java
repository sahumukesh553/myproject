package com.virtusa;

import org.jboss.logging.Logger;

public class MyLogger {
	public static	final Logger logger=Logger.getLogger("com.virtusa");
}
