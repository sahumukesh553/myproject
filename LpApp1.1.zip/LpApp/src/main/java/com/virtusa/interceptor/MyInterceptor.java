package com.virtusa.interceptor;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.virtusa.MyLogger;

public class MyInterceptor extends HandlerInterceptorAdapter {
static final String[] DAY= {"","SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"};
//	@Override
//	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
//			throws Exception {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
//			throws Exception {
//		// TODO Auto-generated method stub
//		
//	}

	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object obj) throws Exception {
		Calendar cal=Calendar.getInstance();
		int day=cal.get(cal.DAY_OF_WEEK);
		MyLogger.logger.info("Today is "+DAY[day]);
		if(day==1)
		{
			res.getWriter().write("<h1> site is under maintenace</h1>");
			return false;
		}
		return true;
	}

}
