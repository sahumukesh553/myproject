package com.virtusa.dao;
import java.util.List;


import org.springframework.orm.hibernate3.HibernateTemplate;

import com.virtusa.MyLogger;
import com.virtusa.model.Calender;
import com.virtusa.model.Lp;



public class LpDaoImpl implements LpDao {
	

private HibernateTemplate template;

	
	public HibernateTemplate getTemplate() {
	return template;
}

public void setTemplate(HibernateTemplate template) {
	this.template = template;
}

	@Override
	public void save(Lp lp) {
		// TODO Auto-generated method stub
		 template.persist(lp);
	}

	@Override
	public void update(Lp lp) {
		List<Lp> list=(List<Lp>) template.find("from Lp where email=?",lp.getEmail());
		Lp oldlp=list.get(0);
		lp.setCourse(oldlp.getCourse());
		lp.setGender(oldlp.getGender());
		 template.update(lp);
	}

	@Override
	public void delete(Lp lp) {
		// TODO Auto-generated method stub
		 template.delete(lp);
	}
public List<Lp> list()
{
	return (List<Lp>) template.find("From Lp");
}
public boolean varifyLogin(Lp lp)
{ boolean result=false;
	List<Lp> list;
	MyLogger.logger.info(lp.getEmail());
		 list=(List<Lp>) template.find("from Lp where email=? and password=?",lp.getEmail(),lp.getPassword());
		 MyLogger.logger.info(list.size());
		 if(list.size()==1)
		 result=true;
return result;
}

@Override
public List<Calender> viewCalender() {
	
			List<Calender> loadAll = template.loadAll(Calender.class);
			MyLogger.logger.info(loadAll);
			return loadAll;
}
}
