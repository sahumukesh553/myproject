package com.virtusa.dao;

import java.util.List;

import com.virtusa.model.Calender;
import com.virtusa.model.Lp;

public interface LpDao {
	void save(Lp lp);
	void update(Lp lp);
	void delete(Lp lp);
	List<Lp> list();
 boolean varifyLogin(Lp lp);
 List<Calender> viewCalender();
	
	

}
