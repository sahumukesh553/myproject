package com.virtusa.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.virtusa.MyLogger;
import com.virtusa.model.*;
import com.virtusa.model.Calender;
import com.virtusa.model.Mentor;

public class MentorDaoImpl implements MentorDao {

private HibernateTemplate template;
	public HibernateTemplate getTemplate() {
	return template;
}

public void setTemplate(HibernateTemplate template) {
	this.template = template;
}

	@Override
	public boolean verifyLogin(Mentor mentor) {
		boolean result=false;
	List<Mentor>	list=(List<Mentor>) template.find("from Mentor where email=? and password=?",mentor.getEmail(),mentor.getPassword());
		result=!list.isEmpty();
	return result;
	}

	@Override
	public int createBatch(BatchDetail batch) {
		
		
		int result=0;
		List<String> present2=(List<String>) template.find("select batchName from BatchDetail");
		if(present2.contains(batch.getBatchName()))
		{
			return 1;
		}
		 MyLogger.logger.info(batch);
			List<Lp> list=template.loadAll(Lp.class);
			MyLogger.logger.info("list size"+list);
			
			
			List<String> present=(List<String>) template.find("select email from Trainee");
			MyLogger.logger.info("present list of trainee"+present);
			List<Trainee> trainees=new ArrayList();
			int count=0;
			for (Lp lp : list) {
				if(present.contains(lp.getEmail()))
				{MyLogger.logger.info("contains");
					continue;
				}
				String name=lp.getName();
				String email=lp.getEmail();
				long mobile=lp.getMobile();
				String profession=lp.getProfession();
				String address=lp.getAddress();
				String gender=lp.getGender();
				String course=lp.getCourse();
				MyLogger.logger.info(lp);
				trainees.add(new Trainee(name, email, mobile, profession,course, address, gender));
				count++;
			}
			batch.setTrainee(trainees);
			if(trainees.isEmpty())
			{
				return 2;
			}else 
			{
			try {
			int v=(int) template.save(batch);
			if(v>0)
			{
				result =3;
			}
			
			}
			catch(Exception e)
				{
					
				}
			}
			
			
		return result;
	}

	@Override
	public boolean publishCalender(String[] dates, String[] topics) {
		if(dates.length!=topics.length)
			return false;
		List<String> olddate=(List<String>) template.find("select date from Calender");
		for(int i=0;i<dates.length;i++)
		{
		if(olddate.contains(dates[i]))
		{System.out.println("duplicate date"+dates[i]);
			continue;
		}
			Calender calender=new Calender(dates[i], topics[i]);
			template.persist(calender);
		}
		return true;
	}

	@Override
	public List<Calender> getCalenderList() {
	List<Calender> list=template.loadAll(Calender.class);
		return list;
	}

	
}
