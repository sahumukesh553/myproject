package com.virtusa.dao;

import java.util.List;

import com.virtusa.model.BatchDetail;
import com.virtusa.model.Calender;
import com.virtusa.model.Mentor;

public interface MentorDao {
boolean verifyLogin(Mentor mentor);
boolean publishCalender(String[] dates,String[] topics);
int createBatch(BatchDetail batch);
List<Calender> getCalenderList();
}
