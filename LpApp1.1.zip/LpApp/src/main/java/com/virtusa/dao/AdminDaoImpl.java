package com.virtusa.dao;

import java.util.List;


import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.virtusa.MyLogger;
import com.virtusa.model.Admin;
import com.virtusa.model.Mail;
import com.virtusa.model.TrainingRoom;

public class AdminDaoImpl implements AdminDao{
	
	private HibernateTemplate template;
	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}

	@Override
	public boolean verifyLogin(Admin admin) {
	boolean	result=false;
	List<Admin>	list=(List<Admin>) template.find("from Admin where email=? and password=?",admin.getEmail(),admin.getPassword());
		result=!list.isEmpty();
	return result;
	}

	@Override
	public int bookVenue(TrainingRoom room) {
		int result=21;
		int value=0;
		List<TrainingRoom> list=(List<TrainingRoom>) template.find("from TrainingRoom where roomId=? and roomName=?",room.getRoomId(),room.getRoomName());
		if(list.isEmpty()||list==null)
			return 21;
		TrainingRoom myroom=list.get(0);
		MyLogger.logger.info(list);
		MyLogger.logger.info(myroom);
		if(myroom.getRoomStatus().equals("booked")&&room.getRoomStatus().equals("booked"))
		{
			return 20;
		}
		System.err.println(room);
		room.setAddress(myroom.getAddress());
		room.setRoomCapacity(myroom.getRoomCapacity());
		
		try
		{
			template.update(room);	
			result=23;
		}catch(Exception ex)
		{
			result=22;
		}
		return result;
	}

	@Override
	public boolean informMentor(Mail mail) {
		return Mailer.send(mail.getFrom(), mail.getPassword(), mail.getTo(), mail.getSubject(),mail.getMessage());
		
	}


}
